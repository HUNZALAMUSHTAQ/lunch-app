import React, { useCallback, useMemo, useRef } from "react";
import { View, Text, StyleSheet, Image } from "react-native";
import BottomSheet from "@gorhom/bottom-sheet";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import BackDropComp from "../../components/BackdropComp";
import HeartIcon from "@app/assests/Heart.svg";

const DetailedLunch = ({ route }) => {
  // ref
  // const { lunchName } = route.params;
  const lunchName = route.params.lunchName;
  console.log(lunchName);
  const bottomSheetRef = useRef();

  // variables
  const snapPoints = useMemo(() => ["15%", "50%"], []);

  // callbacks
  const handleSheetChanges = useCallback((index) => {
    console.log("handleSheetChanges", index);
  }, []);

  // renders
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <View style={styles.container}>
        <BottomSheet
          ref={bottomSheetRef}
          index={1}
          snapPoints={snapPoints}
          onChange={handleSheetChanges}
          backd
          backdropComponent={() => <BackDropComp />}
        >
          <View style={styles.contentContainer}>
            <View style={styles.stack}>
              <Text style={styles.main}>{lunchName}</Text>
              <HeartIcon />
            </View>
            <Text style={{ color: "#7B6F72", fontSize: 12 }}>
              By Hunzala Mushtaq
            </Text>

            <Text style={[styles.main, { marginVertical: 15 }]}>
              Description
            </Text>

            <Text style={{ color: "#7B6F72", fontSize: 12 }}>
              Pancakes are some people's favorite breakfast, who doesn't like
              pancakes? Especially with the real honey splash on top of the
              pancakes, of course everyone loves that! besides being Read
              More...
            </Text>
          </View>
        </BottomSheet>
      </View>
    </GestureHandlerRootView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  contentContainer: {
    flex: 1,
    // alignItems: "center",
    margin: 20,
  },
  stack: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginVertical: 5,
  },
  main: {
    fontSize: 18,
    fontWeight: "600",
    lineHeight: 24,
  },
});
export default DetailedLunch;
