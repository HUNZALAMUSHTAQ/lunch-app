export const LUNCH_DATA = [
  {
    id: "bd7acbea-c1b1-46c2-aed5-3ad53abb28ba",
    //   id: 0,
    lunchTitle: "Honey pancakes",
    lunchTime: "07:00am",
    checked: false,
    disabled: false,
  },
  {
    id: "3ac68afc-c605-48d3-a4f8-fbd91aa97f63",
    //   id: 1,

    lunchTitle: "Coffee",
    lunchTime: "07:00am",
    checked: false,
    disabled: false,
  },
  {
    id: "58694a0f-3da1-471f-bd96-145571e29d72",
    //   id: 2,

    lunchTitle: "Chicken Steak",
    lunchTime: "07:00am",
    checked: false,
    disabled: false,
  },
  {
    id: "58694a0f-3da1-471f-bd96-14557ads72",
    //   id: 2,

    lunchTitle: "Milk",
    lunchTime: "07:00am",
    checked: false,
    disabled: false,
  },
];
